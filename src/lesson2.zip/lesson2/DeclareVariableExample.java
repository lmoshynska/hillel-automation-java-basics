package lesson2;

public class DeclareVariableExample {

    public static void main(String[] args) {
/*        int a;
        System.out.println(a);
        a = 23;

        b = 4.5f;
        System.out.println(b);

        boolean bool = true;
        long l = 456;
        l += bool;

        double d = 65.05;
        d = 75;
        int i = (int)d;*/

//        byte b = 1;
//        int w = 200;

        int j = 10;
        double k = j;
        System.out.println(k);
    }
}
