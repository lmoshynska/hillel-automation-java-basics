package lesson2;

public class VariablesExample {

    public static void main(String[] args) {
        //character or ASCII value variable
        char c = 'w';
        char a = 78;

        //true/false variable
        boolean bool = true;

        //whole number variables
        byte b = 127;
        short s = 32100;
        int i = 1000000;
        long l = 5000000000000L;

        //floating point variables
        float f = 2.356f;
        double d = 5.12345;

        System.out.println(c);
        System.out.println(a);
        System.out.println(bool);
        System.out.println(b);
        System.out.println(s);
        System.out.println(i);
        System.out.println(l);
        System.out.println(f);
        System.out.println(d);
    }
}
