package lesson2;

public class Tasks {

    /* For each task print result into console
       1. Convert 5 hours into minutes.
       2. Calculate a square of the rectangular triangle, 2 sides' values are given.
       3. Given 3 numbers, calculate the average for their squared values.
       4. Given t in Fahrenheit, convert it to Celsius. tC = (tF - 32) x 5/9.
       5. Given t in Celsius, convert it to Kelvin. Kelvin = tC + 273.16.
     */

    public static void main(String[] args) {

        //Solution to Task 1
        int hours = 5;
        int minutes = hours * 60;
        System.out.println(hours + " hours is " + minutes + " minutes");

    }

}
